import math
import os
import sys

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import core  # noqa: E402


def ladder(strikes, probs):
    return pd.DataFrame({"strike": strikes, "prob": probs})


# ---------------------------------------------------------------- expected value
def test_expected_value_worked_example():
    imp = core.implied_distribution(ladder([0.1, 0.2, 0.3], [0.9, 0.6, 0.2]))
    assert imp.expected == pytest.approx(0.27)
    assert imp.dist["probability"].sum() == pytest.approx(1.0)
    assert imp.step == pytest.approx(0.1)
    assert list(imp.dist["outcome"]) == pytest.approx([0.1, 0.2, 0.3, 0.4])
    assert not imp.monotone_adjusted


def test_non_monotone_prices_are_smoothed():
    imp = core.implied_distribution(ladder([0.1, 0.2, 0.3], [0.9, 0.5, 0.6]))
    assert imp.monotone_adjusted
    assert (imp.dist["probability"] >= 0).all()
    assert imp.dist["probability"].sum() == pytest.approx(1.0)


def test_gap_wider_than_step_uses_mean_of_possible_prints():
    # strikes 0.1 and 0.4 with step forced to 0.1 -> possible prints 0.2, 0.3, 0.4 -> mean 0.3
    imp = core.implied_distribution(ladder([0.1, 0.4], [0.8, 0.2]), step=0.1)
    row = imp.dist.iloc[1]
    assert row["outcome"] == pytest.approx(0.3)
    assert row["probability"] == pytest.approx(0.6)


def test_needs_two_strikes():
    with pytest.raises(core.DataError):
        core.implied_distribution(ladder([0.2], [0.5]))
    with pytest.raises(core.DataError):
        core.implied_distribution(ladder([0.2, 0.3], [None, 0.5]))


def test_all_probability_mass_certain():
    imp = core.implied_distribution(ladder([0.1, 0.2, 0.3], [1.0, 1.0, 1.0]))
    assert imp.expected == pytest.approx(0.4)  # certain to print above top strike


def test_prob_vs_consensus():
    imp = core.implied_distribution(ladder([0.1, 0.2, 0.3], [0.9, 0.6, 0.2]))
    pv = core.prob_vs_consensus(imp.dist, 0.2, imp.step)
    assert pv["above"] == pytest.approx(0.6)   # 0.3 (40%) + 0.4 (20%)
    assert pv["inline"] == pytest.approx(0.3)
    assert pv["below"] == pytest.approx(0.1)


def test_estimated_car():
    assert core.estimated_car(0.07, -0.5) == pytest.approx(-0.035)
    assert math.isnan(core.estimated_car(None, -0.5))
    assert math.isnan(core.estimated_car(0.1, None))


# ---------------------------------------------------------------- pricing
def test_mid_price_when_tight():
    p, src, sp = core.implied_probability({"yes_bid": 55, "yes_ask": 60, "last_price": 40})
    assert (round(p, 3), src) == (0.575, "mid")
    assert sp == pytest.approx(0.05)


def test_wide_spread_falls_back_to_last():
    p, src, _ = core.implied_probability({"yes_bid": 3, "yes_ask": 97, "last_price": 3})
    assert (p, src) == (pytest.approx(0.03), "last")


def test_no_price_returns_none():
    p, src, _ = core.implied_probability({"yes_bid": 0, "yes_ask": 0, "last_price": 0})
    assert p is None and src == "none"


def test_dollar_string_fields_supported():
    p, src, _ = core.implied_probability({"yes_bid_dollars": "0.5600", "yes_ask_dollars": "0.6000"})
    assert p == pytest.approx(0.58) and src == "mid"


# ---------------------------------------------------------------- ladder / events
MARKETS = [
    {"ticker": "KXCPI-26SEP-T0.1", "event_ticker": "KXCPI-26SEP", "close_time": "2026-10-14T12:25:00Z",
     "strike_type": "greater", "floor_strike": 0.1, "yes_bid": 88, "yes_ask": 92, "volume": 10},
    {"ticker": "KXCPI-26SEP-T0.2", "event_ticker": "KXCPI-26SEP", "close_time": "2026-10-14T12:25:00Z",
     "strike_type": "greater", "floor_strike": None, "yes_bid": 58, "yes_ask": 62, "volume": 20},  # strike from ticker
    {"ticker": "KXCPI-26SEP-B0.2", "event_ticker": "KXCPI-26SEP", "close_time": "2026-10-14T12:25:00Z",
     "strike_type": "between", "floor_strike": 0.2, "yes_bid": 30, "yes_ask": 34},                  # ignored
    {"ticker": "KXCPI-26OCT-T0.1", "event_ticker": "KXCPI-26OCT", "close_time": "2026-11-12T12:25:00Z",
     "strike_type": "greater", "floor_strike": 0.1, "yes_bid": 70, "yes_ask": 74},
]


def test_list_events_sorted_by_close():
    ev = core.list_events(MARKETS)
    assert list(ev["event_ticker"]) == ["KXCPI-26SEP", "KXCPI-26OCT"]
    assert list(ev["n_markets"]) == [3, 1]


def test_build_ladder_filters_and_parses():
    lad = core.build_ladder(MARKETS, "KXCPI-26SEP")
    assert list(lad["strike"]) == [0.1, 0.2]
    assert lad["prob"].tolist() == pytest.approx([0.90, 0.60])


def test_empty_inputs_do_not_crash():
    assert core.list_events([]).empty
    assert core.build_ladder([], "X").empty


# ---------------------------------------------------------------- network layer
def test_fetch_follows_pagination(monkeypatch):
    pages = [{"markets": [{"a": 1}], "cursor": "c1"}, {"markets": [{"a": 2}], "cursor": ""}]
    calls = []

    def fake(url, params=None, **kw):
        calls.append(dict(params))
        return pages[len(calls) - 1]

    monkeypatch.setattr(core, "_get_json", fake)
    out = core.fetch_open_markets(" kxcpi ")
    assert len(out) == 2
    assert calls[0]["series_ticker"] == "KXCPI" and calls[1]["cursor"] == "c1"


def test_fetch_blank_series_errors():
    with pytest.raises(core.DataError):
        core.fetch_open_markets("  ")


def test_get_json_gives_friendly_error(monkeypatch):
    import requests

    def boom(*a, **k):
        raise requests.ConnectionError("no network")

    monkeypatch.setattr(core.requests, "get", boom)
    monkeypatch.setattr(core.time, "sleep", lambda s: None)
    with pytest.raises(core.DataError, match="Kalshi request failed"):
        core._get_json("http://x", retries=2)


# ---------------------------------------------------------------- quotes
def test_closes_from_multiindex_download():
    idx = pd.date_range("2026-10-20", periods=3)
    cols = pd.MultiIndex.from_product([["TLT", "KRE"], ["Close", "Open"]])
    raw = pd.DataFrame(np.arange(12).reshape(3, 4).astype(float), index=idx, columns=cols)
    s = core._closes(raw, "TLT")
    assert len(s) == 3
    row = core._quote_row("TLT", s)
    assert row["Price"] == s.iloc[-1] and row["Day %"] == pytest.approx((s.iloc[-1] / s.iloc[-2] - 1) * 100)


def test_quote_row_handles_empty():
    row = core._quote_row("XYZ", pd.Series(dtype=float))
    assert math.isnan(row["Price"]) and row["Ticker"] == "XYZ"


# ---------------------------------------------------------------- coefficients
def test_normalize_gammas_fills_missing_with_placeholder():
    df = pd.DataFrame({"Ticker": ["tlt", "gld"], "gamma1": [-1.2, "oops"]})
    out = core.normalize_gammas(df)
    assert len(out) == len(core.UNIVERSE)
    assert out.set_index("Ticker").loc["TLT", "gamma1"] == pytest.approx(-1.2)
    assert out.set_index("Ticker").loc["GLD", "source"] == "placeholder"
    assert out.set_index("Ticker").loc["KRE", "gamma1"] == core.PLACEHOLDER_GAMMA


def test_normalize_gammas_requires_columns():
    with pytest.raises(core.DataError):
        core.normalize_gammas(pd.DataFrame({"foo": [1]}))
    with pytest.raises(core.DataError):
        core.normalize_gammas(pd.DataFrame({"ticker": ["TLT"]}))


def test_default_gammas_survives_missing_file(tmp_path):
    out = core.default_gammas(tmp_path / "nope.csv")
    assert len(out) == len(core.UNIVERSE) and (out["source"] == "placeholder").all()


def test_shipped_gammas_csv_is_valid():
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "gammas.csv")
    out = core.default_gammas(path)
    assert set(out["Ticker"]) == set(core.UNIVERSE["Ticker"])


# ---------------------------------------------------------------- universe / history
def test_universe_is_the_nine_etfs():
    assert list(core.UNIVERSE["Ticker"]) == ["TIP", "GLD", "XLRE", "UUP", "VTIP", "KRE", "QQQ", "TLT", "SHY"]
    assert {"Name", "Group", "Exposure"} <= set(core.UNIVERSE.columns)


def test_naive_index_strips_timezone():
    idx = pd.date_range("2026-10-01", periods=3, tz="America/New_York")
    out = core._naive_index(pd.Series([1.0, 2.0, 3.0], index=idx))
    assert out.index.tz is None and len(out) == 3


# ================================================================ tail-risk monitor
import datetime  # noqa: E402
import types  # noqa: E402


def test_default_sensitivity_values_and_csv_in_sync():
    d = core.sensitivity_defaults().set_index("Ticker")
    assert set(d.index) == set(core.UNIVERSE["Ticker"])
    assert d.loc["SHY", "ols_m"] == -1.13533 and d.loc["SHY", "q95_b"] == 0.1983
    assert d.loc["KRE", "q95_b"] == 3.52465 and d.loc["UUP", "q05_m"] == 4.51495
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "sensitivity_params.csv")
    f = core.default_sensitivity(path).set_index("Ticker")
    for c in core.SENS_COLS:
        assert list(f[c]) == pytest.approx(list(d.loc[f.index, c]))


def test_normalize_sensitivity_keeps_previous_value_on_bad_cell():
    prev = core.sensitivity_defaults()
    edited = prev.copy()
    edited.loc[edited.Ticker == "TLT", "ols_m"] = float("nan")     # cleared cell
    edited["q05_b"] = edited["q05_b"].astype(object)
    edited.loc[edited.Ticker == "QQQ", "q05_b"] = "junk"            # non-numeric
    edited.loc[edited.Ticker == "SHY", "ols_m"] = -2.0              # real edit
    out = core.normalize_sensitivity(edited, fallback=prev).set_index("Ticker")
    assert out.loc["TLT", "ols_m"] == -5.20376
    assert out.loc["QQQ", "q05_b"] == -1.2662
    assert out.loc["SHY", "ols_m"] == -2.0


def test_prediction_interval_values():
    out = core.prediction_intervals(core.sensitivity_defaults(), 0.1).set_index("Ticker")
    r = out.loc["SHY"]
    assert r["y_ols"] == pytest.approx(-1.13533 * 0.1 + 0.0238787)
    assert r["lower"] == pytest.approx(-1.2333 * 0.1 - 0.199291)
    assert r["upper"] == pytest.approx(-1.273 * 0.1 + 0.1983)
    assert not r["adjusted"]


def test_prediction_interval_guardrail_fixes_crossing():
    # UUP at +0.5pp: q05 (1.5609) ends up ABOVE q95 (1.4911) -> must be re-ordered
    r = core.prediction_intervals(core.sensitivity_defaults(), 0.5).set_index("Ticker").loc["UUP"]
    assert r["y_q05"] > r["y_q95"]
    assert r["lower"] == pytest.approx(r["y_q95"]) and r["upper"] == pytest.approx(r["y_q05"])
    assert r["lower"] <= r["y_ols"] <= r["upper"] and r["adjusted"]


def test_prediction_interval_without_divergence_is_nan():
    out = core.prediction_intervals(core.sensitivity_defaults(), None)
    assert out["lower"].isna().all() and not out["adjusted"].any()


def _ladder_markets(oi=500, spread_half=1, event="E"):
    strikes = [-0.1, 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6]
    probs = [99, 98, 90, 65, 23, 6, 2, 1]
    out = []
    for s, p in zip(strikes, probs):
        m = {"ticker": f"T{s}", "event_ticker": event, "strike_type": "greater", "floor_strike": s,
             "yes_bid": p - spread_half, "yes_ask": p + spread_half}
        if oi is not None:
            m["open_interest_fp"] = f"{oi:.2f}"
        out.append(m)
    return out


def test_count_prefers_fp_strings_and_falls_back_to_legacy():
    assert core._count({"open_interest_fp": "20422.00", "open_interest": 1}, "open_interest") == 20422.0
    assert core._count({"open_interest": 77}, "open_interest") == 77.0
    assert core._count({}, "open_interest") is None


def test_tail_metrics_known_distribution():
    tm = core.tail_metrics(_ladder_markets(), "E", consensus=0.20)
    assert tm.n_used == 8 and tm.n_total == 8 and tm.oi_filter_applied
    assert tm.prob_up == pytest.approx(0.23)      # prints 0.4, 0.5, 0.6, 0.7
    assert tm.prob_down == pytest.approx(0.02)    # prints -0.1, 0.0
    assert tm.tail_prob == pytest.approx(0.25)
    assert tm.cond_shock == pytest.approx(0.24)
    assert tm.covers_up and tm.covers_down
    assert tm.std == pytest.approx(
        float(((tm.dist.outcome - (tm.dist.outcome * tm.dist.probability).sum()) ** 2 * tm.dist.probability).sum() ** 0.5))


def test_tail_metrics_drops_low_open_interest_strikes():
    mk = _ladder_markets()
    mk[6]["open_interest_fp"] = "10.00"   # strike 0.5
    mk[7]["open_interest_fp"] = "49.00"   # strike 0.6 (just under 50 -> dropped)
    tm = core.tail_metrics(mk, "E", 0.20)
    assert tm.n_used == 6 and tm.n_total == 8


def test_tail_metrics_drops_wide_spread_strikes():
    mk = _ladder_markets()
    mk[2].update(yes_bid=80, yes_ask=96)   # 16c spread -> dropped
    mk[3].update(yes_bid=58, yes_ask=73)   # 15c spread -> kept (not wider than 15)
    tm = core.tail_metrics(mk, "E", 0.20)
    assert tm.n_used == 7


def test_tail_metrics_too_few_liquid_strikes_raises_clear_error():
    with pytest.raises(core.DataError, match="liquidity filters"):
        core.tail_metrics(_ladder_markets(oi=5), "E", 0.20)


def test_tail_metrics_skips_oi_filter_if_field_missing():
    tm = core.tail_metrics(_ladder_markets(oi=None), "E", 0.20)
    assert not tm.oi_filter_applied and tm.n_used == 8


def test_tail_metrics_enforces_monotone_probabilities():
    mk = _ladder_markets()
    mk[4].update(yes_bid=69, yes_ask=71)   # strike 0.3 priced 70% > strike 0.2 at 65%
    tm = core.tail_metrics(mk, "E", 0.20)
    assert tm.monotone_adjusted and (tm.dist["probability"] >= 0).all()
    assert tm.dist["probability"].sum() == pytest.approx(1.0)


def test_tail_metrics_flags_incomplete_tail_coverage():
    # strikes 0.1-0.3: top lump sits at 0.4 (>= 0.35, covered) but nothing reaches the lower tail (<= 0.05)
    mk = [m for m in _ladder_markets() if m["floor_strike"] in (0.1, 0.2, 0.3)]
    tm = core.tail_metrics(mk, "E", 0.20)
    assert not tm.covers_down and tm.covers_up
    # strikes 0.0-0.2: lower tail covered, upper lump sits at 0.3 (< 0.35) so upper tail is NOT covered
    mk = [m for m in _ladder_markets() if m["floor_strike"] in (0.0, 0.1, 0.2)]
    tm = core.tail_metrics(mk, "E", 0.20)
    assert tm.covers_down and not tm.covers_up


# ---------------------------------------------------------------- options (fake yfinance)
def _fake_yf(options=("2026-11-04",), spot=100.0, calls=None, puts=None, vix=19.0, vix_ok=True, chain_ok=True):
    mod = types.ModuleType("yfinance")
    cols = ["strike", "bid", "ask", "lastPrice"]
    calls = calls if calls is not None else pd.DataFrame([[99, 3, 3.2, 3.1], [100, 1.9, 2.1, 2.0], [101, 1, 1.2, 1.1]], columns=cols)
    puts = puts if puts is not None else pd.DataFrame([[99, 0.9, 1.1, 1.0], [100, 1.4, 1.6, 1.5], [101, 2.2, 2.4, 2.3]], columns=cols)

    class T:
        def __init__(self, sym):
            self.sym = sym
            self.fast_info = {"last_price": spot}
            self.options = tuple(options)

        def option_chain(self, exp):
            if not chain_ok:
                raise RuntimeError("no chain")
            return types.SimpleNamespace(calls=calls, puts=puts)

        def history(self, period="5d", **k):
            if self.sym == "^VIX":
                if not vix_ok:
                    raise RuntimeError("vix down")
                return pd.DataFrame({"Close": [18.0, vix]})
            return pd.DataFrame({"Close": [spot]})

    mod.Ticker = T
    return mod


def _with_fake_yf(fake, fn):
    old = sys.modules.get("yfinance")
    sys.modules["yfinance"] = fake
    try:
        return fn()
    finally:
        if old is None:
            sys.modules.pop("yfinance", None)
        else:
            sys.modules["yfinance"] = old


TODAY = datetime.date(2026, 11, 2)


def test_options_atm_straddle_percent_of_spot():
    om = _with_fake_yf(_fake_yf(), lambda: core.fetch_options_move("QQQ", today=TODAY))
    assert om.source == "options"
    assert om.strike == 100.0 and om.expiry == "2026-11-04" and om.dte == 2
    assert om.move_pct == pytest.approx((2.0 + 1.5) / 100.0 * 100)


def test_options_uses_last_trade_when_book_is_empty():
    cols = ["strike", "bid", "ask", "lastPrice"]
    calls = pd.DataFrame([[100, 0, 0, 2.0]], columns=cols)
    puts = pd.DataFrame([[100, 0, 0, 1.5]], columns=cols)
    om = _with_fake_yf(_fake_yf(calls=calls, puts=puts), lambda: core.fetch_options_move("TLT", today=TODAY))
    assert om.source == "options_last" and om.move_pct == pytest.approx(3.5)


def test_options_falls_back_to_vix_when_chain_empty():
    om = _with_fake_yf(_fake_yf(options=()), lambda: core.fetch_options_move("QQQ", today=TODAY))
    assert om.source == "vix_fallback"
    assert om.move_pct == pytest.approx(19.0 / (252 ** 0.5))


def test_options_falls_back_to_vix_when_chain_errors_or_all_expired():
    om = _with_fake_yf(_fake_yf(chain_ok=False), lambda: core.fetch_options_move("QQQ", today=TODAY))
    assert om.source == "vix_fallback"
    om2 = _with_fake_yf(_fake_yf(options=("2026-10-01",)), lambda: core.fetch_options_move("QQQ", today=TODAY))
    assert om2.source == "vix_fallback"


def test_options_unavailable_when_everything_fails():
    om = _with_fake_yf(_fake_yf(options=(), vix_ok=False), lambda: core.fetch_options_move("QQQ", today=TODAY))
    assert om.source == "unavailable" and om.move_pct != om.move_pct  # NaN


# ---------------------------------------------------------------- options for many ETFs
def _fake_yf_multi(good=("QQQ",), vix=20.0, counters=None):
    """Fake yfinance: tickers in `good` have a priced chain, everything else has none."""
    mod = types.ModuleType("yfinance")
    cols = ["strike", "bid", "ask", "lastPrice"]
    calls = pd.DataFrame([[100, 1.9, 2.1, 2.0]], columns=cols)
    puts = pd.DataFrame([[100, 1.4, 1.6, 1.5]], columns=cols)
    counters = counters if counters is not None else {}

    class T:
        def __init__(self, sym):
            self.sym = sym
            self.fast_info = {"last_price": 100.0}
            self.options = ("2026-11-04",) if sym in good else ()

        def option_chain(self, exp):
            return types.SimpleNamespace(calls=calls, puts=puts)

        def history(self, period="5d", **k):
            if self.sym == "^VIX":
                counters["vix"] = counters.get("vix", 0) + 1
                return pd.DataFrame({"Close": [vix - 1, vix]})
            return pd.DataFrame({"Close": [100.0]})

    mod.Ticker = T
    return mod


def test_options_moves_cover_every_ticker_and_fetch_vix_once():
    counters = {}
    tickers = list(core.UNIVERSE["Ticker"])
    out = _with_fake_yf(_fake_yf_multi(good=("QQQ", "TLT"), counters=counters),
                        lambda: core.fetch_options_moves(tickers, today=TODAY))
    assert set(out) == set(tickers) and len(out) == 9
    assert out["QQQ"].source == "options" and out["QQQ"].move_pct == pytest.approx(3.5)
    assert out["TLT"].source == "options"
    for t in tickers:
        if t not in ("QQQ", "TLT"):
            assert out[t].source == "vix_fallback" and out[t].move_pct == pytest.approx(20.0 / 252 ** 0.5)
    assert counters["vix"] == 1          # shared, not once per ticker


def test_options_moves_vix_fallback_can_be_restricted():
    out = _with_fake_yf(_fake_yf_multi(good=()),
                        lambda: core.fetch_options_moves(["QQQ", "TLT", "GLD"], vix_fallback_tickers=["QQQ"], today=TODAY))
    assert out["QQQ"].source == "vix_fallback"
    assert out["TLT"].source == "unavailable" and "disabled" in out["TLT"].note
    assert out["GLD"].source == "unavailable"


def test_options_moves_never_fetch_vix_if_all_chains_priced():
    counters = {}
    _with_fake_yf(_fake_yf_multi(good=("QQQ", "TLT"), counters=counters),
                  lambda: core.fetch_options_moves(["QQQ", "TLT"], today=TODAY))
    assert counters.get("vix", 0) == 0


def test_options_moves_empty_input():
    assert _with_fake_yf(_fake_yf_multi(), lambda: core.fetch_options_moves([])) == {}
